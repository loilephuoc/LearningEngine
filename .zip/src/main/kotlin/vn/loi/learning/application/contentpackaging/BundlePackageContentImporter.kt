package vn.loi.learning.application.contentpackaging

import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

/**
 * Chuyển bundle package chuẩn mới thành dữ liệu Domain chưa được lưu.
 *
 * Class này không thay thế importer legacy và không truy cập repository.
 */
class BundlePackageContentImporter(
    private val json: Json = Json {
        ignoreUnknownKeys = true
    }
) {

    fun importContent(
        bundle: PackageImportBundle
    ): ImportedPackageContent {
        val contentsJson =
            json.decodeFromString<PackageExportContentsJson>(
                bundle.contentsJson()
            )

        val learningItemsJson =
            json.decodeFromString<PackageExportLearningItemsJson>(
                bundle.learningItemsJson()
            )

        val manifestJson =
            json.decodeFromString<PackageExportManifestJson>(
                bundle.manifestJson()
            )

        require(manifestJson.contentCount == contentsJson.contents.size) {
            "Manifest content count ${manifestJson.contentCount} does not match imported content count ${contentsJson.contents.size}."
        }

        require(manifestJson.learningItemCount == learningItemsJson.learningItems.size) {
            "Manifest learning item count ${manifestJson.learningItemCount} does not match imported learning item count ${learningItemsJson.learningItems.size}."
        }

        return ImportedPackageContent(
            contents = contentsJson.contents.map(PackageExportContentJson::toDomain),
            learningItems = learningItemsJson.learningItems.map(PackageExportLearningItemJson::toDomain)
        )
    }
}