package vn.loi.learning.application.contentpackaging

/**
 * Manifest OPD3 được ghi vào manifest.json.
 */
data class PackageExportManifest(
    val name: String,
    val version: String,
    val format: String,
    val contentCount: Int,
    val learningItemCount: Int
)
