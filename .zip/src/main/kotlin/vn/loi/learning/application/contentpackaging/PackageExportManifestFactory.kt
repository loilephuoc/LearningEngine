package vn.loi.learning.application.contentpackaging

/**
 * Tạo manifest OPD3 từ PackageExportPayload.
 */
class PackageExportManifestFactory {

    fun create(
        payload: PackageExportPayload
    ): PackageExportManifest =
        PackageExportManifest(
            name = payload.descriptor.name,
            version = payload.descriptor.version,
            format = payload.descriptor.format,
            contentCount = payload.contents.size,
            learningItemCount = payload.learningItems.size
        )
}
