package vn.loi.learning.application.contentpackaging

import kotlinx.serialization.Serializable

/**
 * DTO JSON tương thích với manifest mà JvmOpd3PackageDescriptorReader đọc.
 */
@Serializable
data class PackageExportManifestJson(
    val name: String,
    val version: String,
    val format: String,
    val contentCount: Int,
    val learningItemCount: Int
) {

    companion object {
        fun from(
            manifest: PackageExportManifest
        ): PackageExportManifestJson =
            PackageExportManifestJson(
                name = manifest.name,
                version = manifest.version,
                format = manifest.format,
                contentCount = manifest.contentCount,
                learningItemCount = manifest.learningItemCount
            )
    }
}
