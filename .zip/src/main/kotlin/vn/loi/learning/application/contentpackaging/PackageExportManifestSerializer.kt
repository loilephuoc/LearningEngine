package vn.loi.learning.application.contentpackaging

import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Chuyển PackageExportManifest thành JSON.
 */
class PackageExportManifestSerializer(
    private val json: Json = Json { prettyPrint = true }
) {

    fun serialize(
        manifest: PackageExportManifest
    ): String =
        json.encodeToString(
            PackageExportManifestJson.from(manifest)
        )
}
