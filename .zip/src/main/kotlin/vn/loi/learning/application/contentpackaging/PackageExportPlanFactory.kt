package vn.loi.learning.application.contentpackaging

/**
 * Xây dựng kế hoạch export từ payload.
 * Hiện tại chỉ bao gồm manifest.json; các bước tiếp theo sẽ bổ sung metadata, contents và learning-items.
 */
class PackageExportPlanFactory(
    private val manifestFactory: PackageExportManifestFactory = PackageExportManifestFactory(),
    private val manifestFileFactory: PackageExportManifestFileFactory = PackageExportManifestFileFactory()
) {

    fun create(
        payload: PackageExportPayload
    ): PackageExportPlan {
        val manifest = manifestFactory.create(payload)
        return PackageExportPlan(
            files = listOf(
                PackageExportMetadataFileFactory().create(payload.descriptor),
                PackageExportContentsFileFactory().create(payload.contents),
                PackageExportLearningItemsFileFactory().create(payload.learningItems),
                manifestFileFactory.create(manifest)
            )
        )
    }
}
