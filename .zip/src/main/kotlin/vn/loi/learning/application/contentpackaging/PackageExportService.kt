package vn.loi.learning.application.contentpackaging

class PackageExportService(
    private val exporter: PackageContentExporter
 ) {

    fun export(
        payload: PackageExportPayload,
        destination: String
    ): PackageExportBundle {
        val manifest = PackageExportManifestFactory().create(payload)

        val bundle = PackageExportBundle(
            files = listOf(
                PackageExportMetadataFileFactory().create(payload.descriptor),
                PackageExportContentsFileFactory().create(payload.contents),
                PackageExportLearningItemsFileFactory().create(payload.learningItems),
                PackageExportManifestFileFactory().create(manifest)
            )
        )

        exporter.exportContent(
            payload,
            manifest,
            destination
        )

        require(bundle.isNotEmpty()) {
            "Export bundle must not be empty."
        }

        return bundle
    }
}
