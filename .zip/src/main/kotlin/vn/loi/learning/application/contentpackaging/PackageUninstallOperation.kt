﻿package vn.loi.learning.application.contentpackaging

import vn.loi.learning.application.port.ContentLibraryRepository
import vn.loi.learning.application.port.ContentRepository
import vn.loi.learning.application.port.LearningItemRepository
import vn.loi.learning.application.port.ContentPackageRepository
import vn.loi.learning.application.port.PackageCatalogRepository

class PackageUninstallOperation(
    private val contentLibraryRepository: ContentLibraryRepository,
    private val contentRepository: ContentRepository,
    private val learningItemRepository: LearningItemRepository,
    private val contentPackageRepository: ContentPackageRepository,
    private val packageCatalogRepository: PackageCatalogRepository
) {

    fun execute(
        command: UninstallContentPackageCommand
    ) {
        val catalog =
            packageCatalogRepository.findById(command.catalogId)
                ?: return

        val contentPackage =
            contentPackageRepository.findById(command.packageId)

        val updatedCatalog =
            catalog.remove(command.packageId)

        contentPackage?.libraryIds?.forEach { libraryId ->
            contentLibraryRepository.findById(libraryId)
                ?.contentIds
                ?.forEach { contentId ->
                    learningItemRepository.findByContentId(contentId)
                        .forEach { learningItem ->
                            learningItemRepository.deleteById(learningItem.id)
                        }

                    contentRepository.deleteById(contentId)
                }

            contentLibraryRepository.deleteById(libraryId)
        }

        packageCatalogRepository.save(updatedCatalog)
        contentPackageRepository.deleteById(command.packageId)
    }
}


