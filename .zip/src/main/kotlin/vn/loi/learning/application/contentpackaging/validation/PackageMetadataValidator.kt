﻿package vn.loi.learning.application.contentpackaging.validation

import vn.loi.learning.domain.content.packaging.model.PackageDescriptor

class PackageMetadataValidator {

    fun validate(
        descriptor: PackageDescriptor
    ): PackageValidationReport {
        val issues = mutableListOf<PackageValidationIssue>()

        if (descriptor.format != SUPPORTED_FORMAT) {
            issues += PackageValidationIssue(
                code = "UNSUPPORTED_PACKAGE_FORMAT",
                message = "Unsupported package format: ${descriptor.format}. Expected $SUPPORTED_FORMAT.",
                severity = PackageValidationSeverity.ERROR
            )
        }

        if (!isSupportedVersion(descriptor.version)) {
            issues += PackageValidationIssue(
                code = "INVALID_PACKAGE_VERSION",
                message = "Invalid package version: ${descriptor.version}.",
                severity = PackageValidationSeverity.ERROR
            )
        }

        return PackageValidationReport(
            issues = issues
        )
    }

    private fun isSupportedVersion(
        version: String
    ): Boolean {
        val parts = version.split(".")

        return parts.isNotEmpty() &&
            parts.all { part ->
                part.isNotEmpty() && part.all(Char::isDigit)
            }
    }

    companion object {

        const val SUPPORTED_FORMAT = "OPD3"
    }
}
