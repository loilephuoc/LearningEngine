﻿package vn.loi.learning.application.contentpackaging

import vn.loi.learning.application.port.ContentLibraryRepository
import vn.loi.learning.application.port.ContentRepository
import vn.loi.learning.application.port.LearningItemRepository
import vn.loi.learning.application.port.TransactionRunner
import vn.loi.learning.domain.content.packaging.model.PackageCatalogId

/**
 * Điều phối toàn bộ workflow import Content Package.
 *
 * Việc scan, đọc và chuyển đổi package được thực hiện trước transaction.
 * Toàn bộ thay đổi repository của từng package được ghi trong một
 * transaction duy nhất.
 */
class PackageImportService(
    private val packageScanner: PackageScanner,
    private val packageInstaller: PackageInstaller,
    private val packageContentImporter: PackageContentImporter,
    private val contentRepository: ContentRepository,
    private val learningItemRepository: LearningItemRepository,
    private val packageRegistrationOperation: PackageRegistrationOperation,
    private val transactionRunner: TransactionRunner,
    private val contentLibraryRepository: ContentLibraryRepository? = null
) {

    fun importAll(
        catalogId: PackageCatalogId
    ): List<PackageImportResult> =
        packageScanner.scan().map { candidate ->
            importCandidate(
                catalogId = catalogId,
                candidate = candidate
            )
        }

    fun importCandidate(
        catalogId: PackageCatalogId,
        candidate: PackageScanCandidate
    ): PackageImportResult {
        val contentPackage =
            packageInstaller.install(candidate)

        val importedContent =
            packageContentImporter.importContent(candidate)

        return transactionRunner.runInTransaction {
            importedContent.libraries.forEach { library ->
                contentLibraryRepository?.save(library)
            }

            importedContent.contents.forEach { content ->
                contentRepository.save(content)
            }

            importedContent.learningItems.forEach { learningItem ->
                learningItemRepository.save(learningItem)
            }

            packageRegistrationOperation.execute(
                RegisterContentPackageCommand(
                    catalogId = catalogId,
                    contentPackage = contentPackage.registerAll(importedContent.libraries.map { it.id }.toSet())
                )
            )

            PackageImportResult(
                contentPackage = contentPackage.registerAll(importedContent.libraries.map { it.id }.toSet()),
                importedLibraryCount =
                    importedContent.importedLibraryCount,
                importedContentCount =
                    importedContent.contents.size,
                importedLearningItemCount =
                    importedContent.learningItems.size,
                warnings = importedContent.warnings
            )
        }
    }
}


