package vn.loi.learning.application.contentpackaging

/**
 * SHA-256 thuần Kotlin để Application Layer không phụ thuộc java.security.
 */
class Sha256PackageIntegrityHasher :
    PackageIntegrityHasher {

    override fun hash(
        content: String
    ): String =
        digest(
            content.encodeToByteArray()
        ).joinToString(
            separator = ""
        ) { byte ->
            byte.toUByte()
                .toString(16)
                .padStart(
                    length = 2,
                    padChar = '0'
                )
        }

    private fun digest(
        input: ByteArray
    ): ByteArray {
        val paddedInput =
            pad(
                input
            )

        var hash0 = INITIAL_HASH[0]
        var hash1 = INITIAL_HASH[1]
        var hash2 = INITIAL_HASH[2]
        var hash3 = INITIAL_HASH[3]
        var hash4 = INITIAL_HASH[4]
        var hash5 = INITIAL_HASH[5]
        var hash6 = INITIAL_HASH[6]
        var hash7 = INITIAL_HASH[7]

        val words =
            IntArray(
                64
            )

        var blockOffset = 0

        while (
            blockOffset <
            paddedInput.size
        ) {
            for (
            index in 0 until 16
            ) {
                val offset =
                    blockOffset +
                            index * 4

                words[index] =
                    ((paddedInput[offset].toInt() and 0xff) shl 24) or
                            ((paddedInput[offset + 1].toInt() and 0xff) shl 16) or
                            ((paddedInput[offset + 2].toInt() and 0xff) shl 8) or
                            (paddedInput[offset + 3].toInt() and 0xff)
            }

            for (
            index in 16 until 64
            ) {
                val sigma0 =
                    rotateRight(
                        words[index - 15],
                        7
                    ) xor
                            rotateRight(
                                words[index - 15],
                                18
                            ) xor
                            (words[index - 15] ushr 3)

                val sigma1 =
                    rotateRight(
                        words[index - 2],
                        17
                    ) xor
                            rotateRight(
                                words[index - 2],
                                19
                            ) xor
                            (words[index - 2] ushr 10)

                words[index] =
                    words[index - 16] +
                            sigma0 +
                            words[index - 7] +
                            sigma1
            }

            var a = hash0
            var b = hash1
            var c = hash2
            var d = hash3
            var e = hash4
            var f = hash5
            var g = hash6
            var h = hash7

            for (
            index in 0 until 64
            ) {
                val sum1 =
                    rotateRight(
                        e,
                        6
                    ) xor
                            rotateRight(
                                e,
                                11
                            ) xor
                            rotateRight(
                                e,
                                25
                            )

                val choice =
                    (e and f) xor
                            (e.inv() and g)

                val temporary1 =
                    h +
                            sum1 +
                            choice +
                            ROUND_CONSTANTS[index] +
                            words[index]

                val sum0 =
                    rotateRight(
                        a,
                        2
                    ) xor
                            rotateRight(
                                a,
                                13
                            ) xor
                            rotateRight(
                                a,
                                22
                            )

                val majority =
                    (a and b) xor
                            (a and c) xor
                            (b and c)

                val temporary2 =
                    sum0 +
                            majority

                h = g
                g = f
                f = e
                e =
                    d +
                            temporary1
                d = c
                c = b
                b = a
                a =
                    temporary1 +
                            temporary2
            }

            hash0 += a
            hash1 += b
            hash2 += c
            hash3 += d
            hash4 += e
            hash5 += f
            hash6 += g
            hash7 += h

            blockOffset += 64
        }

        return intArrayOf(
            hash0,
            hash1,
            hash2,
            hash3,
            hash4,
            hash5,
            hash6,
            hash7
        ).flatMap { value ->
            listOf(
                (value ushr 24).toByte(),
                (value ushr 16).toByte(),
                (value ushr 8).toByte(),
                value.toByte()
            )
        }.toByteArray()
    }

    private fun pad(
        input: ByteArray
    ): ByteArray {
        val bitLength =
            input.size.toLong() * 8L

        val paddingLength =
            (
                    56 -
                            (
                                    input.size + 1
                                    ) % 64 +
                            64
                    ) % 64

        val result =
            ByteArray(
                input.size +
                        1 +
                        paddingLength +
                        8
            )

        input.copyInto(
            destination =
                result
        )

        result[input.size] =
            0x80.toByte()

        for (
        index in 0 until 8
        ) {
            result[result.lastIndex - index] =
                (
                        bitLength ushr
                                (
                                        index * 8
                                        )
                        ).toByte()
        }

        return result
    }

    private fun rotateRight(
        value: Int,
        bitCount: Int
    ): Int =
        (
                value ushr bitCount
                ) or
                (
                        value shl
                                (
                                        32 - bitCount
                                        )
                        )

    private companion object {

        val INITIAL_HASH =
            intArrayOf(
                0x6a09e667,
                0xbb67ae85.toInt(),
                0x3c6ef372,
                0xa54ff53a.toInt(),
                0x510e527f,
                0x9b05688c.toInt(),
                0x1f83d9ab,
                0x5be0cd19
            )

        val ROUND_CONSTANTS =
            intArrayOf(
                0x428a2f98,
                0x71374491,
                0xb5c0fbcf.toInt(),
                0xe9b5dba5.toInt(),
                0x3956c25b,
                0x59f111f1,
                0x923f82a4.toInt(),
                0xab1c5ed5.toInt(),
                0xd807aa98.toInt(),
                0x12835b01,
                0x243185be,
                0x550c7dc3,
                0x72be5d74,
                0x80deb1fe.toInt(),
                0x9bdc06a7.toInt(),
                0xc19bf174.toInt(),
                0xe49b69c1.toInt(),
                0xefbe4786.toInt(),
                0x0fc19dc6,
                0x240ca1cc,
                0x2de92c6f,
                0x4a7484aa,
                0x5cb0a9dc,
                0x76f988da,
                0x983e5152.toInt(),
                0xa831c66d.toInt(),
                0xb00327c8.toInt(),
                0xbf597fc7.toInt(),
                0xc6e00bf3.toInt(),
                0xd5a79147.toInt(),
                0x06ca6351,
                0x14292967,
                0x27b70a85,
                0x2e1b2138,
                0x4d2c6dfc,
                0x53380d13,
                0x650a7354,
                0x766a0abb,
                0x81c2c92e.toInt(),
                0x92722c85.toInt(),
                0xa2bfe8a1.toInt(),
                0xa81a664b.toInt(),
                0xc24b8b70.toInt(),
                0xc76c51a3.toInt(),
                0xd192e819.toInt(),
                0xd6990624.toInt(),
                0xf40e3585.toInt(),
                0x106aa070,
                0x19a4c116,
                0x1e376c08,
                0x2748774c,
                0x34b0bcb5,
                0x391c0cb3,
                0x4ed8aa4a,
                0x5b9cca4f,
                0x682e6ff3,
                0x748f82ee,
                0x78a5636f,
                0x84c87814.toInt(),
                0x8cc70208.toInt(),
                0x90befffa.toInt(),
                0xa4506ceb.toInt(),
                0xbef9a3f7.toInt(),
                0xc67178f2.toInt()
            )
    }
}